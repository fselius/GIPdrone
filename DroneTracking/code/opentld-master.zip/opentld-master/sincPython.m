
detectFlag = 0;

fileID = fopen('_input_noa\\frame_num.txt','w');
fprintf(fileID,'%d',1);
fclose(fileID);

var2 = 1;
var1 = '_input_noa\\in%06d.jpg';
fullPath = System.IO.Path.GetFullPath('.\\...\\detectMoveAndBoundingBox.py');
fullPath = strrep(fullPath.char, '\','\\');
command=sprintf('python %s %s %d',fullPath, var1, var2);
fprintf('%s\n',command);
system(command);

%if ~status
%    detectFlag = 1;
%end 
   
%if detectFlag  
    frameInd  = run_TLD();
%    var2 = frameInd;
%    command=sprintf('python %s  %s %d',fullPath, var1, var2);
%    fprintf('%s\n',command);
%    system(command);
    
    %[bb,conf, frameInd] = tldExample(opt);
    %run_TLD();

%end