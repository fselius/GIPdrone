clf; figure(1);

subplot('position',[0 0 1 1]);
imshow(0);

subplot('position',[0.5 0 1 1]);
imshow(1);
